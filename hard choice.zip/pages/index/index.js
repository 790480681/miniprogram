//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    exponent:{},
    exponentAmend:false,
    exponentDisplay:false,
    factor:[],
    factorDisplay:false,
    factorIndex:-1,
    factorString:"",
    option:[],
    optionDisplay:false,
    optionString:"",
    result:null,
    reveal:false,
    sum:[],
    title:"????",
    titleString:"",
    value:[],
    valueString:"",
  },
  addFactor:function(f){
    var exponent_=this.data.exponent,
      factor_=this.data.factor,
      option_=this.data.option,
      string0=this.data.factorString,
      string1=this.data.valueString,
      value_=this.data.value,
      i;
    if(string0=="" || string1==""){return;}
    string1=parseFloat(string1);
    if (string1< -10 || 10< string1)
    {
      wx.showToast({
        duration: 2000,
        icon: "none",
        title: "分值异常",})
      return;
    }
    i=0;
    while(i< factor_.length)
    {
      if(string0==factor_[i])
      {
        wx.showToast({
          duration: 2000,
          icon: "none",
          title: "已存因素",})
        return;
      }
      ++i;
    }
    factor_.push(1);
    factor_[factor_.length-1]=string0;
    i=0;
    while(i< option_.length)
    {
      exponent_[option_[i]][string0]=0;
      ++i;
    }
    value_.push(1);
    value_[value_.length-1]=string1;
    this.setData({
      exponent:exponent_,
      factor:factor_,
      value:value_,})
    wx.showToast({duration:1000,})},
  addOption:function(f){
    var exponent_=this.data.exponent,
      factor_=this.data.factor,
      option_=this.data.option,
      string=this.data.optionString,
      i;
    if(string==""){return;}
    i=0;
    while(i< option_.length)
    {
      if(string==option_[i])
      {
        wx.showToast({
          duration: 2000,
          icon: "none",
          title: "已存选项",})
        return;
      }
      ++i;
    }
    option_.push(1);
    option_[option_.length-1]=string,
    exponent_[string]={};
    i=0;
    while(i< factor_.length)
    {
      exponent_[string][factor_[i]]=0;
      ++i;
    }
    this.setData({
      exponent:exponent_,
      option:option_,})
    wx.showToast({duration:1000,})},
  amendExponent:function(f){
    var exponent_=this.data.exponent,
      factor_=this.data.factor,
      factorIndex_=this.data.factorIndex,
      index=f.currentTarget.dataset.in,
      option_=this.data.option,
      string=f.detail.value;
    if(string==""){return;}
    string=parseFloat(string);
    if(string< -10 || 10< string)
    {
      wx.showToast({
        duration: 2000,
        icon: "none",
        title: "分值异常",})
      return;
    }
    exponent_[option_[index]][factor_[factorIndex_]]=string;
    this.setData({exponent:exponent_,})},
  amendTitle:function(f){
    var string=this.data.titleString;
    if(string==""){return;}
    this.setData({title:string,})},
  calculation:function(f){
    var factor_=this.data.factor,
      exponent_=this.data.exponent,
      option_=this.data.option,
      result_=0,
      sum_=[],
      value_=this.data.value,
      i=0,j;
    while(i< option_.length)
    {
      sum_.push(1);
      sum_[i]=0;
      j=0
      while(j< factor_.length)
      {
        sum_[i]+=value_[j]*exponent_[option_[i]][factor_[j]];
        j++;
      }
      if(sum_[result_]< sum_[i]){result_=i;}
      ++i;
    }
    this.setData({
      result:result_,
      reveal:this.data.reveal?false:true,
      sum:sum_})},
  consoleLog:function(f){
    console.log(this.data.exponent);
    console.log(this.data.factor);
    console.log(this.data.option);
    console.log(this.data.value);},
  deleteFactor:function(f){
    var exponent_=this.data.exponent,
      factor_=this.data.factor,
      index=f.currentTarget.dataset.in,
      option_=this.data.option,
      value_=this.data.value,
      i=0;
    while(i< factor_.length && 0< option_.length)
    {
      delete exponent_[option_[i]][factor_[index]];
      ++i;
    }
    factor_.splice(index,1);
    value_.splice(index,1);
    this.setData({
      exponent:exponent_,
      factor:factor_,
      value:value_,})},
  deleteOption:function(f){
    var exponent_=this.data.exponent,
      index=f.currentTarget.dataset.in,
      option_=this.data.option,
      value_=this.data.value;
    delete exponent_[option_[index]];
    option_.splice(index,1);
    this.setData({
      exponent:exponent_,
      option:option_,})},
  displayExponent:function(f){
    this.setData({
      exponentDisplay:this.data.exponentDisplay?false:true,
      factorIndex:f.currentTarget.dataset.in,})},
  displayFactor:function(f){this.setData({factorDisplay:this.data.factorDisplay?false:true,})},
  displayOption:function(f){this.setData({optionDisplay:this.data.optionDisplay?false:true,})},
  help:function(){
    wx.showModal({
      title: "用法",
      content: "有问题，列选项。查因素，添改删。评分值，正负十。逐个填，帮我选。",
    })},
  inputFactor:function(f){this.data.factorString=f.detail.value;},
  inputOption:function(f){this.data.optionString=f.detail.value;},
  inputTitle:function(f){this.data.titleString=f.detail.value;},
  inputValue:function(f){this.data.valueString=f.detail.value;},
  startExponent:function(f){this.setData({exponentAmend:this.data.exponentAmend?false:true,})},

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
