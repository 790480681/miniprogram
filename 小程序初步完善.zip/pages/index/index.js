//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    exponent:{},
    exponentAmend:false,
    exponentDisplay:false,
    exponentNull:null,
    factor:[],
    factorAmend:false,
    factorDisplay:false,
    factorString:"",
    option:[],
    optionAmend:false,
    optionDisplay:false,
    optionString:"",
    result:[],
    title:"????",
    titleString:"",
    value:[],
    valueNull:null,
    valueString:"",
  },
  addFactor:function(f){
    var factor_=this.data.factor;
    var string=this.data.factorString;
    if(string==""){return;}
    factor_.push(1);
    factor_[factor_.length-1]=string;
    this.setData({factor:factor_,})},
  addOption:function(f){
    var option_=this.data.option,
      string0=this.data.optionString,
      string1=this.data.valueString,
      value_=this.data.value;
    if(string0=="" || string1==""){return;}
    option_.push(1);
    option_[option_.length-1]=string0,
    value_.push(1);
    if(parseFloat(string1)==NaN){string1=0;}
    else{value_[value_.length-1]=parseFloat(string1);}
    this.setData({
      option:option_,
      value:value_,})},
  amendExponent:function(f){
    },
  amendFactor:function(f){
    },
  amendOption:function(f){
    },
  amendTitle:function(f){
    var string=this.data.titleString;
    if(string==""){return;}
    this.setData({
      title:string,
      titleString:"",
      titleValue:"",})},
  calculation:function(f){
    },
  cancelExponent:function(f){},
  cancelFactor:function(f){},
  cancelOption:function(f){},
  deleteFactor:function(f){
    var factor_=this.data.factor,
      index=f.currentTarget.dataset.in;
      factor_.splice(index,1);
      this.setData({factor:factor_,})},
  deleteOption:function(f){
    var index=f.currentTarget.dataset.in,
      option_=this.data.option,
      value_=this.data.value;
    option_.splice(index,1);
    value_.splice(index,1);
    this.setData({
      option:option_,
      value:value_,})},
  displayExponent:function(f){
    var bool=this.data.exponentDisplay;
    this.setData({exponentDisplay:bool?false:true,})},
  displayFactor:function(f){
    var bool=this.data.factorDisplay;
    this.setData({factorDisplay:bool?false:true,})},
  displayOption:function(f){
    var bool=this.data.optionDisplay;
    this.setData({optionDisplay:bool?false:true,})},
  inputFactor:function(f){this.data.factorString=f.detail.value;},
  inputOption:function(f){this.data.optionString=f.detail.value;},
  inputTitle:function(f){this.data.titleString=f.detail.value;},
  inputValue:function(f){this.data.valueString=f.detail.value;},
  startExponent:function(f){
    var bool=this.data.exponentAmend;
    this.setData({exponentAmend:bool?false:true,})},
  startFactor:function(f){
    var bool=this.data.factorAmend;
    this.setData({factorAmend:bool?false:true,})},
  startOption:function(f){
    var bool=this.data.optionAmend;
    this.setData({optionAmend:bool?false:true,})},

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
